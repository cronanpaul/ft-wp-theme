# Bootstrap Blog

Build on the official Bootstrap blog starter template to learn WordPress.

### [View the tutorial!](https://www.taniarascia.com/developing-a-wordpress-theme-from-scratch/)
