<div class="ft-post">
<!--
	<h2 class="ft-post-title"><?php the_title(); ?></h2>
	<p class="ft-post-meta"><?php the_date(); ?> by <a href="#"><?php the_author(); ?></a></p>
-->

 <?php the_content(); ?>

</div><!-- /.ft-post -->