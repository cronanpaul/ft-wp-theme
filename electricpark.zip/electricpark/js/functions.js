var scroll_index;

$(document).ready(function(){
    
    console.log('OK all systems go');
  
    if ($('.page-item-2').hasClass('current_page_item')) {
        $('.ft-nav').hide().removeClass('nav-on').addClass('nav-off').delay( 5500 ).show().switchClass('nav-off','nav-on');
    }
    
    $.scrollify({
		section : ".ft-section",
		sectionName : "panelid",
		interstitialSection : "",
		easing: "easeOutExpo",
		scrollSpeed: 1100,
		offset: 0,
		scrollbars: true,
		standardScrollElements: ".ft-text",
		setHeights: true,
		overflowScroll: true,
		updateHash: true,
		touchScroll:true,
		before:function(index,sections) {
            scroll_index = index;
            checkSection(index, sections);
        },
		after:function(index,sections) {
            scroll_index = index;
            checkSection(index, sections);
        },
		afterResize:function(index,sections) {
            $.scrollify.move(scroll_index);
        },
		afterRender:function(index,sections) {
            checkSection(index, sections);
            useContents(index, sections);
            showPurchaseOptions();
            hidePurchaseOptions();
        }
	});
    
    function checkSection(index, sections) {
        
        var destination = $.scrollify.current().attr('data-panelid');
        
        if(destination == 'panel_0'){
            $('#ft-about-contents').hide();
        } else {
            $('#intro-logo').hide();
            $('.ft-nav').removeClass('nav-off');
            $('#ft-about-contents').fadeIn('slow');
            $('.active').removeClass('active');
            $('#ft-about-contents-'+index).addClass('active');
        }
    }
    
    function useContents(index, sections) {
        $('#ft-about-contents-1').on('click', function(){
            $.scrollify.move("#panel_1");
        });
        $('#ft-about-contents-2').on('click', function(){
            $.scrollify.move("#panel_2");
        });
        $('#ft-about-contents-3').on('click', function(){
            $.scrollify.move("#panel_3");
        });
        $('#ft-about-contents-4').on('click', function(){
            $.scrollify.move("#panel_4");
        });
        $('#ft-about-contents-5').on('click', function(){
            $.scrollify.move("#panel_5");
        });
    }
    
    function showPurchaseOptions() {
        $('.ft-buy').on('click', function(){
            $('.ft-masthead').toggleClass('options-on');
        });
    }
    
    function hidePurchaseOptions() {
        if ($('.ft-masthead').hasClass('options-on')) {
            $('div').not('#ft-purchase-options').on('click', function(){
                console.log('succcess');
                $('.ft-masthead').toggleClass('options-on');
            });
        }
    }
    
});