var scroll_index;

$(document).ready(function(){
    
    console.log('OK all systems go');
    
    $('.ft-masthead').addClass('masthead-off').delay( 6000 ).switchClass('masthead-off','', 2000, 'easeInOutQuad');
  
    $.scrollify({
		section : ".ft-section",
		sectionName : "panelid",
		interstitialSection : "",
		easing: "easeOutExpo",
		scrollSpeed: 1100,
		offset: 0,
		scrollbars: true,
		standardScrollElements: "",
		setHeights: true,
		overflowScroll: true,
		updateHash: true,
		touchScroll:true,
		before:function(index,sections) {
            checkSection(index, sections);
            scroll_index = index;
        },
		after:function(index,sections) {
            checkSection(index, sections);
            scroll_index = index;
        },
		afterResize:function(index,sections) {
            $.scrollify.move(scroll_index);
        },
		afterRender:function(index,sections) {
            checkSection(index, sections);
            useContents(index, sections);
        }
	});
    
    function checkSection(index, sections) {
        
        var destination = $.scrollify.current().attr('data-panelid');
        
        if(destination == 'panel_0'){
            $('#ft-about-contents').hide();
        } else {
            $('#intro-logo').hide();
            $('.ft-masthead').removeClass('masthead-off');
            $('#ft-about-contents').fadeIn('slow');
            $('.active').removeClass('active');
            $('#ft-about-contents-'+index).addClass('active');
        }
    }
    
    function useContents(index, sections) {
        $('#ft-about-contents-1').on('click', function(){
            $.scrollify.move("#panel_1");
        });
        $('#ft-about-contents-2').on('click', function(){
            $.scrollify.move("#panel_2");
        });
        $('#ft-about-contents-3').on('click', function(){
            $.scrollify.move("#panel_3");
        });
        $('#ft-about-contents-4').on('click', function(){
            $.scrollify.move("#panel_4");
        });
        $('#ft-about-contents-5').on('click', function(){
            $.scrollify.move("#panel_5");
        });
    }
    
});